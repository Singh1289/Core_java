package assignment4;

public class InvalidAgeExecption extends Exception {
	public InvalidAgeExecption(String msg) {
		super(msg);
	}
}
