package assignment4;

public interface StudentFee {
	public int getFee() throws InvalidFeeException;
}
