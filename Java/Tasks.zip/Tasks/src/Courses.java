
public class Courses {
	private Instructor abc;
	
	public void add(Courses a) {}
	
	
}
