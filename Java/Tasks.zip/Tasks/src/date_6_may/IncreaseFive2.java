package date_6_may;

public interface IncreaseFive2 {
	public int inc(int a);
	default int getNo() {return 10;};
	public static String getString() {return "1289";};
}
