package date_6_may;

public class A {
	public double div(int a,int b) {return a/b;}
}
