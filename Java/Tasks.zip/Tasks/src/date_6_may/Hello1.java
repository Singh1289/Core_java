package date_6_may;

@FunctionalInterface
public interface Hello1 {
	public String sayHello();
	//public int getNo();    // no error because there is no @funtional interface
}
