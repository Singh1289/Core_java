package date_6_may;

public class HelloClass1 {
	public static void main(String[] args) {
		Hello1 h = () ->{return "Hello Abhi";};
		System.out.println(h.sayHello());
	}
}
